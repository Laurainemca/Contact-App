package com.ca;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ContactAppActivity extends Activity {
    /** Called when the activity is first created. */
	
	String name1;
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    
    public void onsave(View v)
    {
    	EditText e0 = (EditText) findViewById(R.id.EditText5);
    	EditText e1 = (EditText) findViewById(R.id.editText2);
    	EditText e2 = (EditText) findViewById(R.id.EditText01);
    	EditText e3 = (EditText) findViewById(R.id.EditText02);
    	EditText e4 = (EditText) findViewById(R.id.EditText03);
    	CDB obj = new CDB(this);
    	obj.addcontact(e0.getText().toString(), e2.getText().toString(), e3.getText().toString(), e4.getText().toString());
    	e0.setText("");
    	e2.setText("");
    	e3.setText("");
    	e4.setText("");
    	Toast.makeText(getApplicationContext(), "Contact Saved",Toast.LENGTH_SHORT).show();
    }
    
    public void onfind(View v)
    {
    	
    	String a[];
    	EditText e0 = (EditText) findViewById(R.id.EditText5);
    	EditText e1 = (EditText) findViewById(R.id.editText2);
    	EditText e2 = (EditText) findViewById(R.id.EditText01);
    	EditText e3 = (EditText) findViewById(R.id.EditText02);
    	EditText e4 = (EditText) findViewById(R.id.EditText03);
    	CDB obj = new CDB(this);
    	String name = e1.getText().toString();
    	a = obj.getcontact(name);
    	e0.setText(a[0]);
    	e2.setText(a[1]);
    	e3.setText(a[2]);
    	e4.setText(a[3]);
    	Toast.makeText(getApplicationContext(), "Contact Finded",Toast.LENGTH_LONG).show();
    }
    
    public void ondelete(View v) 
    {
    	EditText e0 = (EditText) findViewById(R.id.EditText5);
    	EditText e1 = (EditText)findViewById(R.id.editText2);
    	EditText e2 = (EditText) findViewById(R.id.EditText01);
    	EditText e3 = (EditText) findViewById(R.id.EditText02);
    	EditText e4 = (EditText) findViewById(R.id.EditText03);
    	CDB objdb = new CDB(this);
    	String name = e1.getText().toString();
    	objdb.deleteContact(name);
    	e0.setText("");
    	e1.setText("");
    	e2.setText("");
    	e3.setText("");
    	e4.setText("");
    	Toast.makeText(getApplicationContext(), "Contact Deleted",Toast.LENGTH_LONG).show();
    }
    
    public void onedit(View v) 
    {
    	EditText e0 = (EditText) findViewById(R.id.EditText5);
    	EditText e1 = (EditText) findViewById(R.id.editText2);
    	EditText e2 = (EditText) findViewById(R.id.EditText01);
    	EditText e3 = (EditText) findViewById(R.id.EditText02);
    	EditText e4 = (EditText) findViewById(R.id.EditText03);
    	CDB objdb = new CDB(this);
    	String name = e1.getText().toString();
    	objdb.updateContact(name, e0.getText().toString(), e2.getText().toString(), e3.getText().toString(), e4.getText().toString());
    	e1.setText("");
    	e0.setText("");
    	e2.setText("");
    	e3.setText("");
    	e4.setText("");
    	Toast.makeText(getApplicationContext(), "Contact Updated",Toast.LENGTH_LONG).show();
    }
}