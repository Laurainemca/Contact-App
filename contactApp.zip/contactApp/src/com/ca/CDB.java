package com.ca;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class CDB extends SQLiteOpenHelper
{
	private static final int DBV = 1;
	private static final String DBN = "CMS";
	public CDB(Context context) 
	{
		super(context, DBN, null, DBV);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) 
	{
		// TODO Auto-generated method stub
		db.execSQL("CREATE TABLE TB_CONTACT(CNO INTEGER PRIMARY KEY AUTOINCREMENT, CNAME TEXT, CNICK TEXT, MOB TEXT, EMAIL TEXT)");
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int arg1, int arg2) 
	{
		// TODO Auto-generated method stub
		db.execSQL("DROP TABLE IF EXISTS TB_CONTACT");
		onCreate(db);
	}

	public void addcontact(String cn, String cnn, String cm, String ce)
	{
		try
		{
			SQLiteDatabase db = this.getWritableDatabase();
			ContentValues cv = new ContentValues();
			cv.put("CNAME", cn);
			cv.put("CNICK", cnn);
			cv.put("MOB", cm);
			cv.put("EMAIL", ce);
			db.insert("TB_CONTACT", null, cv);
			db.close();
		}
		catch(Exception e)
		{
			System.out.println("Error : " +e);
			Log.d("INSERT :", e.toString());
		}
	}
	
	public String[] getcontact(String name)
	{
		String a[] = new String[10];
		try
		{
			SQLiteDatabase db = this.getReadableDatabase();
			Cursor cursor = db.query("TB_CONTACT", new String[] {"CNAME", "CNICK", "MOB", "EMAIL"}, "CNAME = ?" , new String[] {String.valueOf(name)}, null, null, null, null);
			if(cursor!=null && cursor.getCount()!=0)
			{
				cursor.moveToFirst();
				a[0]=cursor.getString(0);
				a[1]=cursor.getString(1);
				a[2]=cursor.getString(2);
				a[3]=cursor.getString(3);
			}
			else
			{
				a[0]="";
				a[1]="";
				a[2]="";
				a[3]="";
				
			}
		}
		catch(Exception e)
		{
			System.out.println("Error : " +e);
			Log.d("SELECT :", e.toString());
		}
		return a;
	}
	
	public int deleteContact(String name)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		return db.delete("TB_CONTACT", "CNAME=?", new String[]{String.valueOf(name)});
	}
	
	public void updateContact(String n, String cn, String cnn, String cm, String ce)
	{
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values=new ContentValues();
		values.put("CNAME", cn);
		values.put("CNICK", cnn);
		values.put("MOB", cm);
		values.put("EMAIL", ce);
		db.update("TB_CONTACT", values, "CNAME=?", new String[]{String.valueOf(n)});
		db.close();
	}
}
